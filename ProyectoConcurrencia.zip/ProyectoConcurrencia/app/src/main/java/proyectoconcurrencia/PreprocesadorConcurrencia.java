package proyectoconcurrencia;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class PreprocesadorConcurrencia {
    
    public static void main(String[] args) {

        String CSVentrada = "./train.csv";
        String TweetsP = "./tweetsP.txt";
        String diccionario = "./diccionarioFiltrado.txt";
        String ArchivoProcesado = "./resultadoProcesado.txt";
        CSVRecord c = null;
        
        try {
            Reader in = new FileReader(CSVentrada);
            CSVParser parser = new CSVParser(in, CSVFormat.EXCEL.withDelimiter(','));
            Iterator it = parser.iterator();
            try {
                FileWriter writer = new FileWriter(TweetsP);
                while (it.hasNext()) {
                    try {
                        c = ((CSVRecord) (it.next()));
                        writer.append(c.get(2));
                        writer.append(System.lineSeparator());
                    } catch (Exception e) {
                        e.printStackTrace();
                        System.out.println(c.getRecordNumber());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        preprocesar(TweetsP, diccionario, ArchivoProcesado);
    }

    public static void preprocesar(
            String EntradaTXT,
            String DiccionarioFile,
            String SalidaTXT) {

        Set<String> diccionario = crearDiccionario(DiccionarioFile);

        try (BufferedReader reader = new BufferedReader(new FileReader(EntradaTXT));
            BufferedWriter writer = new BufferedWriter(new FileWriter(SalidaTXT))){
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.replaceAll("[^a-zA-Z ]", " ");
                String[] palabras = line.split("\\s+");
                StringBuilder nuevaLinea = new StringBuilder();

                for (String palabra : palabras) {
                    if (!diccionario.contains(palabra.toLowerCase())) {
                        nuevaLinea.append(palabra.toLowerCase()).append(" ");
                    }
                }
                writer.write(nuevaLinea.toString().trim());
                writer.newLine();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private static Set<String> crearDiccionario(String dictionaryFile) {
        Set<String> diccionario = new HashSet<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(dictionaryFile));
            String palabra;
            while ((palabra = reader.readLine()) != null) {
                diccionario.add(palabra.toLowerCase());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return diccionario;
    }
}
